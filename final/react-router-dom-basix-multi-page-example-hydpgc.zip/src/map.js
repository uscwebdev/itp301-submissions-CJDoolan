import React from 'react';
import React, { useState, useEffect } from 'react';

export default function Map() {
  return (
    <div>
      <img
        id="mapImage"
        src="https://i.postimg.cc/SNsQvrdY/mapp.png"
        alt="map Image"
      />
    </div>
  );
}
