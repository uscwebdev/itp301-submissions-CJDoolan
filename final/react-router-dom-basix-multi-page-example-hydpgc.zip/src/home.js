import React from 'react';
import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Switch, Route, Link } from 'react-router-dom';

export default function Home() {
  return (
    <div>
      <div class="scrollmenu">
        <img
          className="poster"
          src="https://i.postimg.cc/Nj8y680D/Screen-Shot-2023-11-29-at-3-52-18-PM.png"
          alt="LA Food Festival"
        />
        <img
          className="poster"
          src="https://i.postimg.cc/T3vL5NTh/Screen-Shot-2023-11-29-at-3-52-39-PM.png"
          alt="LA Food Festival"
        />
        <img
          className="poster"
          src="https://i.postimg.cc/8k3rNP3R/Screen-Shot-2023-11-29-at-3-53-00-PM.png"
          alt="LA Food Festival"
        />
        <img
          className="poster"
          src="https://i.postimg.cc/KvM3zhSd/Screen-Shot-2023-11-29-at-3-53-23-PM.png"
          alt="LA Food Festival"
        />
      </div>

      <div id="bubbles">
        <Link to="/menu">
          <img
            className="bubbleLeft"
            src="https://i.postimg.cc/5tGv2BNm/Group-154.png"
            alt="Vendors"
          />
        </Link>
        <img
          className="foodRight"
          src="https://i.postimg.cc/8PgKVQrn/Icons-05.png"
          alt="LA Food Festival"
        />

        <Link to="/map">
          <img
            className="bubbleRight"
            src="https://i.postimg.cc/Twv5gkVt/Group-152.png"
            alt="Map"
          />
        </Link>
        <img
          className="foodLeft"
          src=" https://i.postimg.cc/VNZZyJjj/Icons-03.png"
          alt="LA Food Festival"
        />

        <Link to="shop">
          <img
            className="bubbleLeft"
            src="https://i.postimg.cc/RhhTDSFP/Group-153.png"
            alt="Events"
          />
        </Link>

        <img
          className="foodRight"
          src="https://i.postimg.cc/jd68xgHq/Icons-07.png"
          alt="LA Food Festival"
        />
      </div>
    </div>
  );
}
