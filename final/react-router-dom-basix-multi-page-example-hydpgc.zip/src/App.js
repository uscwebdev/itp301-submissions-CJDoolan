import React from 'react';
import './style.css';

import Link from './Link';

export default function App() {
  return (
    <div>
      <Link />
    </div>
  );
}
