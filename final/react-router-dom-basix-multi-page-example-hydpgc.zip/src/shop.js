import React from 'react';
import React, { useState, useEffect } from 'react';

export default function Shop() {
  return (
    <div>
      <header>
        <img
          className="food"
          src="https://i.postimg.cc/Hntcqmrw/11-12-23-MERCH7.png"
          alt=""
        />
      </header>
      <Item
        src="https://i.postimg.cc/fTpCQzhL/11-12-23-MERCH5.png"
        itemName="Mug Set"
        price="22"
        src2="https://i.postimg.cc/YqhRP4ZZ/11-12-23-MERCH6.png"
        itemName2="Mug Set"
        price2="22"
      />
      <Item
        src="https://i.postimg.cc/tRrDDdSF/11-12-23-MERCH3.png"
        itemName="Bucket Hat"
        price="34"
        src2="https://i.postimg.cc/kgScn0ny/11-12-23-MERCH8.png"
        itemName2="Baseball Cap"
        price2="38"
      />
      <Item
        src="https://i.postimg.cc/Xv0gXsq6/11-12-23-MERCH2.png"
        itemName="Cotton Tee"
        price="25"
        src2="https://i.postimg.cc/g0qHh3LX/11-12-23-MERCH1.png"
        itemName2="Kids Tee"
        price2="20"
      />
    </div>
  );
}

function Item(prop) {
  return (
    <div id="itemGroup">
      <div className="itemComponent">
        <img className="item" src={prop.src} />
        <h4> {prop.itemName} </h4>
        <p className="price"> ${prop.price} </p>
      </div>

      <div className="itemComponent">
        <img className="item" src={prop.src2} />
        <h4> {prop.itemName2} </h4>
        <p className="price"> ${prop.price2} </p>
      </div>
    </div>
  );
}
