import React from 'react';
import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Switch, Route, Link } from 'react-router-dom';

export default function Contact() {
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [subject, setSubject] = useState('');
  const [message, setMessage] = useState('');

  const [fullNameError, setFullNameError] = useState();
  const [emailError, setEmailError] = useState();
  const [subjectError, setSubjectError] = useState();
  const [messageError, setMessageError] = useState();

  function handleSubmit(e) {
    var foundError = false;

    if (fullName.length == 0) {
      foundError = true;
      setFullNameError('You must provide a name');
    } else {
      setFullNameError('');
    }

    if (email.length == 0) {
      foundError = true;
      setEmailError('You must provide email ');
    } else {
      setEmailError('');
    }

    if (subject.length == 0) {
      foundError = true;
      setSubjectError('You must provide email ');
    } else {
      setSubjectError('');
    }

    if (message.length == 0) {
      foundError = true;
      setMessageError('You must provide email ');
    } else {
      setMessageError('');
    }

    if (foundError == true) {
    
      e.preventDefault();
    } else {
      
      alert('The form was successfully submitted.');
    }
  }

  return (
    <div>
      <form onSubmit={handleSubmit}>
        <div id="form">
          <div>
            <label className="label">
              Your Name: <span>*</span>
              <br /> <small> {fullNameError} </small>
            </label>
            <div>
              <input 
              className= "contactInput"
                placeholder="John White"
                onChange={(e) => {
                  setFullName(e.currentTarget.value);
                }}
                value={fullName}
              />
            
            </div>
          </div>

          <div>
            <label className="label">
              Your Email: <span>*</span>
            </label>
            <br /> <small> {emailError} </small>
            <div>
              <input
              className= "contactInput"
                placeholder="Johnwhite@gmail.com"
                onChange={(e) => {
                  console.log(e.currentTarget.value);
                  setEmail(e.currentTarget.value);
                }}
                value={email}
              />
            </div>
          </div>

          <div>
            <label className="label">
              Subject: <span>*</span>
            </label>
            <br /> <small> {subjectError} </small>
            <div>
              <input
              className= "contactInput"
                placeholder="Question about Event Details"
                onChange={(e) => {
                  console.log(e.currentTarget.value);
                  setSubject(e.currentTarget.value);
                }}
                value={subject}
              />
            </div>
            
          </div>

          <div>
            <label className="label">
              Message: <span>*</span>
            </label>
            <br /> <small> {messageError} </small>
            <div>
              <input
              className= "contactInput"
                placeholder="Write your Message"
                onChange={(e) => {
                  console.log(e.currentTarget.value);
                  setMessage(e.currentTarget.value);
                }}
                value={message}
              />
            </div>
            
          </div>


          <button type="submit" className="btn btn-primary">
            Submit
          </button>
        </div>
      </form>

      <Tab
        src="https://i.postimg.cc/sxwK7skF/ic-outline-email.png"
        description="EMAIL"
        socialName="LAFoodFestival@usc.edu"
      />

      <div className="finalIcon">
        <Tab
          className="profileIcon"
          src="https://i.postimg.cc/d3q4hLSm/uil-phone.png"
          description="PHONE"
          socialName="+1(817) 437-0097"
        />
      </div>
    </div>
  );
}

function Tab(props) {
  return (
    <div>
      {' '}
      <hr />
      <div className="extrasCategories">
        <img className="profileIcon" src={props.src} alt="" />
        <h3 className="extrasLabel"> {props.description} </h3>
        <p className="extrasLabels"> {props.socialName}</p>
      </div>
    </div>
  );
}
