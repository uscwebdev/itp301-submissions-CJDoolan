import React from 'react';
import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Switch, Route, Link } from 'react-router-dom';

export default function Socials() {
  return (
    <div>
      
      <Tab
        src="https://i.postimg.cc/bwNJpyCk/devicon-twitter.png"
        description="TWITTER"
        socialName = "facebook.com/LAFoodFestival"
      />
      <Tab
        className="profileIcon"
        src="https://i.postimg.cc/CMkd46nB/ic-baseline-facebook.png"
        description="FACEBOOK"
        socialName = "#LAFoodFestival2023"
      />
      <div className= "finalIcon">
      <Tab
        className="profileIcon"
        src="https://i.postimg.cc/SNDD4Hh6/Group-101.png"
        description="INSTAGRAM"
        socialName = "@LAFoodFestival"
      />
      </div>
    
    </div>

  );
}

function Tab(props) {
  return (
    <div>
      {' '}
      <hr />
      <div className="extrasCategories">
        <img className="profileIcon" src={props.src} alt="" />
        <h3 className="extrasLabel"> {props.description} </h3>
        <p className="extrasLabels"> {props.socialName}</p>
      </div>
    </div>
  );
}
