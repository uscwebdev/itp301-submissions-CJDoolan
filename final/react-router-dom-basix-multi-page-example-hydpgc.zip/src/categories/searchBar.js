import React from 'react';
import { FaSearch } from 'react-icons/fa';
import React, { useState } from 'react';
import { BrowserRouter as Router, Switch, Route, Link } from 'react-router-dom';
import SearchBar from './searchBar.js';

export default function SearchBar(prop) {
  const [input, setInput] = useState('');

  const [enter, setEnter] = useState('/menu');

  const handleInputChange = (value) => {
    setInput(value);

    if (
      value.includes('american') ||
      value.includes('American') ||
      value.includes('urgers') ||
      value.includes('izza') ||
      value.includes('ries') ||
      value.includes('bbq') ||
      value.includes('BBQ') ||
      value.includes('ibs') ||
      value.includes('urgers') ||
      value.includes('risket') ||
      value.includes('ots') ||
      value.includes('reakfast sandwhich')
    ) {
      setEnter('/american');
    } else if (
      value.includes('latin') ||
      value.includes('Latin') ||
      value.includes('Mexican') ||
      value.includes('mexican') ||
      value.includes('acos') ||
      value.includes('orn') ||
      value.includes('argarita') ||
      value.includes('lote') ||
      value.includes('acho') ||
      value.includes('uesadilla')
    ) {
      setEnter('/latin');
    } else if (
      value.includes('asian') ||
      value.includes('chinese') ||
      value.includes('Asian') ||
      value.includes('Chinese') ||
      value.includes('Japanese') ||
      value.includes('japenese') ||
      value.includes('Pho') ||
      value.includes('pho') ||
      value.includes('oodles') ||
      value.includes('umpling') ||
      value.includes('ushi') ||
      value.includes('rice')
    ) {
      setEnter('/asian');
    } else if (
      value.includes('european') ||
      value.includes('European') ||
      value.includes('italian') ||
      value.includes('Italian') ||
      value.includes('german') ||
      value.includes('German') ||
      value.includes('atsa') ||
      value.includes('ysters') ||
      value.includes('burratta') ||
      value.includes('ausage') ||
      value.includes('rilled cheese') ||
      value.includes('izza')
    ) {
      setEnter('/european');
    } else if (
      value.includes('mediteranean') ||
      value.includes('Mediteranean') ||
      value.includes('Middle') ||
      value.includes('middle') ||
      value.includes('ummus') ||
      value.includes('alafel') ||
      value.includes('yro') ||
      value.includes('alafel') ||
      value.includes('amb') ||
      value.includes('hawarma')
    ) {
      setEnter('/mediteranean');
    } else if (
      value.includes('dessert') ||
      value.includes('Dessert') ||
      value.includes('sweet') ||
      value.includes('Sweet') ||
      value.includes('treat') ||
      value.includes('Treat') ||
      value.includes('innamon') ||
      value.includes('onut') ||
      value.includes('reme brulee') ||
      value.includes('reme Brulee')
    ) {
      setEnter('/dessert');
    } else {
      setEnter('/menu');
    }
  };

  return (
    <div>
      <div className="inputWrapper">
        <FaSearch id="search-icon" />
        <input
          className="searchInput"
          placeholder="Ex. american food"
          value={input}
          onChange={(e) => handleInputChange(e.target.value)}
        />

        <Link to={enter} className="nav-link">
          <p> search</p>
        </Link>
      </div>
      <p id="small">
        {' '}
        If the searched keyword is not found in the system, the search will lead
        to this page.
        <br /> Please try a different keyword{' '}
      </p>
    </div>
  );
}

// function LinkTo (prop) {
//   return (
//     <Link to= {prop.enter} className="nav-link">
//     <p> search</p>
//           </Link>
//   )
// }
