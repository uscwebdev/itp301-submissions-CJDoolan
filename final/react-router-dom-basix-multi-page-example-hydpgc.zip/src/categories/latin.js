import React from 'react';
import React, { useState, useEffect } from 'react';
import SearchBar from './searchBar.js';

export default function Menu() {
  const [displayIndex, setDisplayIndex] = useState(0);

  function handleIndexChange(index) {
    setDisplayIndex(index);
  }
  return (
    <div>
      <h1 className="foodHeader"> Latin American </h1>
      <div className="searchBarContainer">
        <SearchBar />
      </div>

      <LatinAmericanVendor
        isActive={displayIndex == 0}
        index={0}
        parentIndexHandler={handleIndexChange}
        category="The Lime Truck"
        url='url("https://i.postimg.cc/XvQkqzLz/Group-84.png")'
        img="https://i.postimg.cc/Wpgy4JNy/Group-168.png"
        link="https://www.thelimetruck.com/menu"
        linkTwo="https://www.thelimetruck.com/?utm_source=google&utm_medium=cpc&utm_term=the%20lime%20truck&utm_campaign=20482459368&utm_content=BRAND-RSA-B&campaignid=20482459368&adgroupid=155545423849&adid=671098123913&gad_source=1&gclid=Cj0KCQiAyKurBhD5ARIsALamXaHFECZGrRYCAtmgjNgKGoVWFchPJ77rF1FNKWtXPDdfLwhP2YLEeqEaAu-pEALw_wcB"
      />
      <LatinAmericanVendor
        isActive={displayIndex == 1}
        index={1}
        parentIndexHandler={handleIndexChange}
        category="G's Taco Spot"
        url='url("https://i.postimg.cc/4d0vbHrv/Group-85.png")'
        img="https://i.postimg.cc/QCQYYvYD/Group-169.png"
        link="https://www.grubhub.com/restaurant/los-elote-men-anaheim-blvd-11205-anaheim-blvd-anaheim/2884250"
        linkTwo="https://www.grubhub.com/restaurant/los-elote-men-anaheim-blvd-11205-anaheim-blvd-anaheim/2884250"
      />

      <LatinAmericanVendor
        isActive={displayIndex == 2}
        index={2}
        parentIndexHandler={handleIndexChange}
        category="Elote Man"
        url='url("https://i.postimg.cc/26yFZ7X8/Group-86.png")'
        img="https://i.postimg.cc/prb1ZPZk/Group-170.png"
        link="https://www.bestfoodtrucks.com/truck/fried-out-la/menu"
        linkTwo="https://www.friedoutla.com/"
      />
    </div>
  );
}

function LatinAmericanVendor(props) {
  var displayContent;

  const handleLinkClick = () => {
    window.location.href = props.link;
  };

  const handleLinkTwoClick = () => {
    window.location.href = props.linkTwo;
  };

  if (props.isActive == true) {
    displayContent = (
      <div className="vendorBox">
        <img className="vendorBoxImage" src={props.img} />
        <div className="contents">
          <button
            onClick={handleLinkClick}
            style={{
              background: 'none',
              border: 'none',
              outline: 'none',
              cursor: 'pointer',
              color: 'white',
            }}
            onMouseOver={(e) => (e.target.style.opacity = 0.5)}
            onMouseOut={(e) => (e.target.style.opacity = 1)}
          >
            <div className="button">
              <img
                className="vendorImage"
                src="https://i.postimg.cc/7ZYnWz0G/1.png"
              />
              <p> Menu</p>
            </div>
          </button>

          <button
            onClick={handleLinkTwoClick}
            style={{
              background: 'none',
              border: 'none',
              outline: 'none',
              cursor: 'pointer',
              color: 'white',
            }}
            onMouseOver={(e) => (e.target.style.opacity = 0.5)}
            onMouseOut={(e) => (e.target.style.opacity = 1)}
          >
            <div className="button">
              {' '}
              <img
                className="vendorImage"
                src="https://i.postimg.cc/P53QsqQ6/2.png"
              />
              <p> Website </p>
            </div>
          </button>
        </div>
      </div>
    );
  }

  return (
    <div>
      <div
        id="american"
        onMouseEnter={() => {
          props.parentIndexHandler(props.index);
        }}
        style={{
          backgroundImage: props.url,
          backgroundRepeat: 'no-repeat',
        }}
      >
        <img
          id="star"
          src=" https://i.postimg.cc/kGQ3Z2mn/ph-star-fill.pngalt"
          alt="star"
        />
        <h2 className="resturaunt"> {props.category}</h2>
      </div>
      {displayContent}
    </div>
  );
}
