import React from 'react';
import React, { useState, useEffect } from 'react';
import SearchBar from './searchBar.js';

export default function Menu() {
  const [displayIndex, setDisplayIndex] = useState(0);

  function handleIndexChange(index) {
    setDisplayIndex(index);
  }

  return (
    <div>
      <h1 className="foodHeader"> Mediteranean</h1>
      <div className="searchBarContainer">
        <SearchBar />
      </div>
      <European
        isActive={displayIndex == 0}
        index={0}
        parentIndexHandler={handleIndexChange}
        category="The Tropic Truck  "
        url='url("https://i.postimg.cc/DZPXzjTM/Group-79.png")'
        img="https://i.postimg.cc/zvTWCrtC/Group-171.png"
        link="https://www.thetropictruck.com/Menu"
        linkTwo="https://www.thetropictruck.com/"
      />
      <European
        isActive={displayIndex == 1}
        index={1}
        parentIndexHandler={handleIndexChange}
        category="The Falafel Factory"
        url='url("https://i.postimg.cc/52DvKQgn/Group-81.png")'
        img="https://i.postimg.cc/CM8jTGhR/Group-172.png"
        link="https://www.bestfoodtrucks.com/truck/the-falafel-factory/menu"
        linkTwo="https://the-falafelfactory.com/"
      />

      <European
        isActive={displayIndex == 2}
        index={2}
        parentIndexHandler={handleIndexChange}
        category=" The Middle Feast"
        url='url("https://i.postimg.cc/HL5MqWPH/Group-82.png")'
        img="https://i.postimg.cc/xTSL0X8t/Group-173.png"
        link="https://themiddlefeastfoodtruck.com/phone/our-food.html"
        linkTwo="https://themiddlefeastfoodtruck.com/phone/index.html"
      />
      <European
        isActive={displayIndex == 3}
        index={3}
        parentIndexHandler={handleIndexChange}
        category="Hummus Yummy"
        url='url("https://i.postimg.cc/ydHRsqwR/Group-83.png")'
        img="https://i.postimg.cc/RFkKJFRC/Group-174.png"
        link="https://hummusyummy.net/menu.html"
        linkTwo="https://hummusyummy.net/"
      />
    </div>
  );
}

function European(props) {
  var displayContent;

  const handleLinkClick = () => {
    window.location.href = props.link;
  };

  const handleLinkTwoClick = () => {
    window.location.href = props.linkTwo;
  };

  if (props.isActive == true) {
    displayContent = (
      <div className="vendorBox">
        <img className="vendorBoxImage" src={props.img} />
        <div className="contents">
          <button
            onClick={handleLinkClick}
            style={{
              background: 'none',
              border: 'none',
              outline: 'none',
              cursor: 'pointer',
              color: 'white',
            }}
            onMouseOver={(e) => (e.target.style.opacity = 0.5)}
            onMouseOut={(e) => (e.target.style.opacity = 1)}
          >
            <div className="button">
              <img
                className="vendorImage"
                src="https://i.postimg.cc/7ZYnWz0G/1.png"
              />
              <p> Menu</p>
            </div>
          </button>

          <button
            onClick={handleLinkTwoClick}
            style={{
              background: 'none',
              border: 'none',
              outline: 'none',
              cursor: 'pointer',
              color: 'white',
            }}
            onMouseOver={(e) => (e.target.style.opacity = 0.5)}
            onMouseOut={(e) => (e.target.style.opacity = 1)}
          >
            <div className="button">
              {' '}
              <img
                className="vendorImage"
                src="https://i.postimg.cc/P53QsqQ6/2.png"
              />
              <p> Website </p>
            </div>
          </button>
        </div>
      </div>
    );
  }

  return (
    <div>
      <div
        id="american"
        onMouseEnter={() => {
          props.parentIndexHandler(props.index);
        }}
        style={{
          backgroundImage: props.url,
          backgroundRepeat: 'no-repeat',
        }}
      >
        <img
          id="star"
          src=" https://i.postimg.cc/kGQ3Z2mn/ph-star-fill.pngalt"
          alt="star"
        />
        <h2 className="resturaunt"> {props.category}</h2>
      </div>
      {displayContent}
    </div>
  );
}
