import React from 'react';
import React, { useState, useEffect } from 'react';
import SearchBar from './searchBar.js';


export default function Menu() {
  const [displayIndex, setDisplayIndex] = useState(0);

  function handleIndexChange(index) {
    setDisplayIndex(index);
  }

  return (
    <div>
      <h1 className="foodHeader"> All American </h1>
      <div className="searchBarContainer">
        <SearchBar />
      </div>

      <AmericanVendor
        isActive={displayIndex == 0}
        index={0}
        parentIndexHandler={handleIndexChange}
        category="Fried Out"
        url='url("https://i.postimg.cc/PfFfy5L3/Group-80.png")'
        img="https://i.postimg.cc/cCPpqjpH/Group-155.png"
        link="https://www.bestfoodtrucks.com/truck/fried-out-la/menu"
        linkTwo="https://www.friedoutla.com/"
      />

      <AmericanVendor
        isActive={displayIndex == 1}
        index={1}
        parentIndexHandler={handleIndexChange}
        category="Holy Cow"
        url='url("https://i.postimg.cc/SNBS01fc/Group-82.png")'
        img="https://i.postimg.cc/pdFD3MV4/Group-158.png"
        link="https://holycowbbq.com/togo-menu"
        linkTwo="https://holycowbbq.com/"
      />

      <AmericanVendor
        isActive={displayIndex == 2}
        index={2}
        parentIndexHandler={handleIndexChange}
        category="The Rooster"
        url='url("https://i.postimg.cc/kgWn7NTz/Group-81.png")'
        img="https://i.postimg.cc/sg8Yngz5/Group-159.png"
        link="https://www.roostereats.com/locations"
        linkTwo="https://www.roostereats.com/"
      />
      <AmericanVendor
        isActive={displayIndex == 3}
        index={3}
        parentIndexHandler={handleIndexChange}
        category="Richeeze"
        url='url("https://i.postimg.cc/rF0VP2x8/Group-83.png")'
        img="https://i.postimg.cc/1340cNk9/Group-160.png"
        link="https://www.richeeseburgers.com/menu"
        linkTwo="https://www.richeeseburgers.com/"
      />
    </div>
  );
}

function AmericanVendor(props) {
  var displayContent;

  const handleLinkClick = () => {
    window.location.href = props.link;
  };

  const handleLinkTwoClick = () => {
    window.location.href = props.linkTwo;
  };

  if (props.isActive == true) {
    displayContent = (
      <div className="vendorBox">
        <img className="vendorBoxImage" src={props.img} />
        <div className="contents">
          <button
            onClick={handleLinkClick}
            style={{
              background: 'none',
              border: 'none',
              outline: 'none',
              cursor: 'pointer',
              color: 'white',
            }}
            onMouseOver={(e) => (e.target.style.opacity = 0.5)}
            onMouseOut={(e) => (e.target.style.opacity = 1)}
          >
            <div className="button">
              <img
                className="vendorImage"
                src="https://i.postimg.cc/7ZYnWz0G/1.png"
              />
              <p> Menu</p>
            </div>
          </button>

          <button
            onClick={handleLinkTwoClick}
            style={{
              background: 'none',
              border: 'none',
              outline: 'none',
              cursor: 'pointer',
              color: 'white',
            }}
            onMouseOver={(e) => (e.target.style.opacity = 0.5)}
            onMouseOut={(e) => (e.target.style.opacity = 1)}
          >
            <div className="button">
              {' '}
              <img
                className="vendorImage"
                src="https://i.postimg.cc/P53QsqQ6/2.png"
              />
              <p> Website </p>
            </div>
          </button>
        </div>
      </div>
    );
  }

  return (
    <div>
      <div
        id="american"
        onMouseEnter={() => {
          props.parentIndexHandler(props.index);
        }}
        style={{
          backgroundImage: props.url,
          backgroundRepeat: 'no-repeat',
        }}
      >
        <img
          id="star"
          src=" https://i.postimg.cc/kGQ3Z2mn/ph-star-fill.pngalt"
          alt="star"
        />
        <h2 className="resturaunt"> {props.category}</h2>
      </div>
      {displayContent}
    </div>
  );
}
