import React from 'react';
import React, { useState, useEffect } from 'react';
import SearchBar from './searchBar.js';

export default function Menu() {
  const [displayIndex, setDisplayIndex] = useState(0);

  function handleIndexChange(index) {
    setDisplayIndex(index);
  }
  return (
    <div>
      <h1 className="foodHeader"> European </h1>
      <div className="searchBarContainer">
        <SearchBar />
      </div>

      <European
        isActive={displayIndex == 0}
        index={0}
        parentIndexHandler={handleIndexChange}
        category="Burrata House"
        url='url("https://i.postimg.cc/8cdrjygY/Group-79.png")'
        img="https://i.postimg.cc/fWJFQgpM/Group-164.png"
        linkTwo="https://burratahouse.com/"
        link="https://burratahouse.com/pages/menu"
      />
      <European
        isActive={displayIndex == 1}
        index={1}
        parentIndexHandler={handleIndexChange}
        category="Berlins"
        url='url("https://i.postimg.cc/TwDbXd7f/Group-81.png")'
        img="https://i.postimg.cc/5jWYyCnb/Group-165.png"
        link="https://eatberlins.com/order-berlins-los-angeles"
        linkTwo="https://eatberlins.com/"
      />

      <European
        isActive={displayIndex == 2}
        index={2}
        parentIndexHandler={handleIndexChange}
        category="The Jolly Oyster"
        url='url("https://i.postimg.cc/mkWHLvJM/Group-82.png")'
        img="https://i.postimg.cc/ZY2Qbxzp/Group-166.png"
        link="https://thejollyoyster.com/?location=the-jolly-oyster-shuck-shack"
        linkTwo="https://thejollyoyster.com/"
      />
      <European
        isActive={displayIndex == 3}
        index={3}
        parentIndexHandler={handleIndexChange}
        category="Sugo"
        url='url("https://i.postimg.cc/GhryZ1kn/Group-83.png")'
        img="https://i.postimg.cc/SN9vJYm5/Group-167.png"
        link="https://www.sugoitaliano.com/menus"
        linkTwo="https://www.sugoitaliano.com/"
      />
    </div>
  );
}

function European(props) {
  var displayContent;

  const handleLinkClick = () => {
    window.location.href = props.link;
  };

  const handleLinkTwoClick = () => {
    window.location.href = props.linkTwo;
  };

  if (props.isActive == true) {
    displayContent = (
      <div className="vendorBox">
        <img className="vendorBoxImage" src={props.img} />
        <div className="contents">
          <button
            onClick={handleLinkClick}
            style={{
              background: 'none',
              border: 'none',
              outline: 'none',
              cursor: 'pointer',
              color: 'white',
            }}
            onMouseOver={(e) => (e.target.style.opacity = 0.5)}
            onMouseOut={(e) => (e.target.style.opacity = 1)}
          >
            <div className="button">
              <img
                className="vendorImage"
                src="https://i.postimg.cc/7ZYnWz0G/1.png"
              />
              <p> Menu</p>
            </div>
          </button>

          <button
            onClick={handleLinkTwoClick}
            style={{
              background: 'none',
              border: 'none',
              outline: 'none',
              cursor: 'pointer',
              color: 'white',
            }}
            onMouseOver={(e) => (e.target.style.opacity = 0.5)}
            onMouseOut={(e) => (e.target.style.opacity = 1)}
          >
            <div className="button">
              {' '}
              <img
                className="vendorImage"
                src="https://i.postimg.cc/P53QsqQ6/2.png"
              />
              <p> Website </p>
            </div>
          </button>
        </div>
      </div>
    );
  }

  return (
    <div>
      <div
        id="american"
        onMouseEnter={() => {
          props.parentIndexHandler(props.index);
        }}
        style={{
          backgroundImage: props.url,
          backgroundRepeat: 'no-repeat',
        }}
      >
        <img
          id="star"
          src=" https://i.postimg.cc/kGQ3Z2mn/ph-star-fill.pngalt"
          alt="star"
        />
        <h2 className="resturaunt"> {props.category}</h2>
      </div>
      {displayContent}
    </div>
  );
}
