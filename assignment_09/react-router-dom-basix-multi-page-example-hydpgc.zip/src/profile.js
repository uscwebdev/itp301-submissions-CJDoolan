import React from 'react';
import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Switch, Route, Link } from 'react-router-dom';

export default function Profile() {
  return (
    <div>
      <Tab
        className="profileIcon"
        link="/socials"
        src="https://i.postimg.cc/5ymp6RFM/Group-99.png"
        description="Socials"
      />

      <Tab
        className="profileIcon"
        link="/partners"
        src="https://i.postimg.cc/SNDD4Hh6/Group-101.png"
        description="Partners"
      />
      <div className="finalIcon">
        <Tab
          className="profileIcon"
          link="/contacts"
          src="https://i.postimg.cc/Dy2Btntf/bx-message.png"
          description="Contact Us"
        />
      </div>
    </div>
  );
}

function Tab(props) {
  return (
    <Link to={props.link} className="nav-link2">
      <div>
        {' '}
        <hr />
        <div className="extrasCategories">
          <img className="profileIcon" src={props.src} alt="" />
          <h3 className="extrasLabel"> {props.description} </h3>
        </div>
      </div>
    </Link>
  );
}
