import React from 'react';
import React, { useState, useEffect } from 'react';

export default function Profile() {
  return (
    <div>
      <Tab 
      src= "https://i.postimg.cc/rwsgwgVv/fluent-info-32-regular.png"
      description = "Info & FAQ's" />
       <Tab 
      src= "https://i.postimg.cc/5ymp6RFM/Group-99.png"
      description = "Socials" />
       <Tab 
      src= "https://i.postimg.cc/SNDD4Hh6/Group-101.png"
      description = "Partners" />
       <Tab 
      src= "https://i.postimg.cc/Dy2Btntf/bx-message.png"
      description = "Contact Us" />
       <Tab 
      src= "https://i.postimg.cc/Wpm5WhYf/fluent-settings-24-regular.png"
      description = "Settings" />
      
    </div>
  );
}


function Tab (props) {
 return (
<div> <hr />
      <div className="extrasCategories">
      <img src = {props.src} alt="" />
      <h3 className="extrasLabel"> {props.description} </h3>
    </div>

    </div>

 ) }