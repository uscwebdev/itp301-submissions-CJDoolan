import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Switch, Route, Link } from 'react-router-dom';
import Home from './home.js';
import Events from './events.js';
import Menu from './menu.js';
import Map from './map.js';
import Shop from './shop.js';
import American from './categories/american.js';
import Asian from './categories/asian.js';
import Dessert from './categories/dessert.js';
import European from './categories/european.js';
import Latin from './categories/latin.js';
import Mediteranean from './categories/mediteranean.js';
import Beverage from './categories/beverage.js';
import Profile from './profile.js';

export default function App() {
  return (
    <Router>
      <header>
        <div id="header">
          <Link to="/" className="nav-link">
            <img src="https://i.postimg.cc/bw199mfk/Group-34.png" alt="" />
            </Link>
            <p id="hello"> Hello Username </p>
            <Link to="/" className="logoLink">
          <img
            className="logo"
            src="https://i.postimg.cc/vBbZ1LWQ/Icons-48.png"
            alt="LA Food Festival"
          />
          </Link>
          <Link to="/profile" className="nav-link">
            <img
              id="bars"
              src="https://i.postimg.cc/9fw5b4Yv/Group-36.png"
              alt=""
            />
          </Link>
        </div>
      </header>

      <div>
        <Switch>
          <Route path="/events">
            <PageLayout>
              <Events />
            </PageLayout>
          </Route>
          <Route path="/menu">
            <PageLayout>
              <Menu />
            </PageLayout>
          </Route>

          <Route path="/map">
            <PageLayout>
              <Map />
            </PageLayout>
          </Route>
          <Route path="/shop">
            <PageLayout>
              <Shop />
            </PageLayout>
          </Route>
          <Route path="/american">
            <PageLayout>
              <American />
            </PageLayout>
          </Route>
          <Route path="/asian">
            <PageLayout>
              <Asian />
            </PageLayout>
          </Route>
          <Route path="/dessert">
            <PageLayout>
              <Dessert />
            </PageLayout>
          </Route>
          <Route path="/european">
            <PageLayout>
              <European />
            </PageLayout>
          </Route>
          <Route path="/latin">
            <PageLayout>
              <Latin />
            </PageLayout>
          </Route>
          <Route path="/mediteranean">
            <PageLayout>
              <Mediteranean />
            </PageLayout>
          </Route>
          <Route path="/beverage">
            <PageLayout>
              <Beverage />
            </PageLayout>
          </Route>
          <Route path="/profile">
            <PageLayout>
              <Profile />
            </PageLayout>
          </Route>

          <Route path="/">
            <PageLayout>
              <Home />
            </PageLayout>
          </Route>
        </Switch>
      </div>

      <nav>
        <ul className="nav-ul">
          <li className="nav-li">
            <Link to="/home" className="nav-link">
              <img src="https://i.postimg.cc/cJLd4Nd6/Vector.png" alt="" />{' '}
              <br />
              Home
            </Link>
          </li>
          {/* <li className="nav-li">
            <Link to="/events" className="nav-link">
              <img src="https://i.postimg.cc/FRfm3gd4/Vector-5.png" alt="" />{' '}
              <br />
              Events
            </Link>
          </li> */}
          <li className="nav-li">
            <Link to="/menu" className="nav-link">
              <img src="https://i.postimg.cc/PxBH4pY8/Vector2.png" alt="" />{' '}
              <br />
              Menu
            </Link>
          </li>
          <li className="nav-li">
            <Link to="/map" className="nav-link">
              <img src="https://i.postimg.cc/PqVTCFqy/Vector3.png" alt="" />{' '}
              <br />
              Map
            </Link>
          </li>
          <li className="nav-li">
            <Link to="/shop" className="nav-link">
              <img src="https://i.postimg.cc/7ZVxkL8p/Group.png" alt="" />{' '}
              <br />
              Shop
            </Link>
          </li>
        </ul>
      </nav>
    </Router>
  );
}

function PageLayout({ children }) {
  return <div>{children}</div>;
}
