import React from 'react';
import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Switch, Route, Link } from 'react-router-dom';

export default function Menu() {
  return (
    <div>
       
      <input placeholder="Search Food Type" />
      <img id="search" src="https://i.postimg.cc/6qjZf5K1/fe-Search0.pngg" />
      <div class="scrolll">
      <VendorCategory
        category="ALL AMERICAN"
        description="Burgers, Pizza, Fries, and More!"
        src="https://i.postimg.cc/fRBf7g6J/Icons-06.png"
        color="#FAB735"
        link="/american"
      />

      <VendorCategory
        category="LATIN AMERICAN"
        description="Tacos, Corn, Margaritas, and More!"
        src="https://i.postimg.cc/zXdJcjyv/Icons-09.png"
        color="#F19846"
        link="/latin"
      />
      <VendorCategory
        category="ASIAN"
        description="Pho, Noodles, Dumpling, and More!"
        src="https://i.postimg.cc/wMLwsFnV/Icons-02.png"
        color="#E47E49"
        link="/asian"
      />

      <VendorCategory
        category="EUROPEAN"
        description="Pasta, Oysters, Burratta, and More!"
        src="https://i.postimg.cc/prbZxzyn/Icons-22.png"
        color="#CE6240"
        link="/european"
      />

      <VendorCategory
        category="MEDITERANEAN"
        description="Falafels, Gyros, Hummes, and More!"
        src="https://i.postimg.cc/8PgKVQrn/Icons-05.png"
        color="#97391B"
        link="/mediteranean"
      />

      <VendorCategory
        category="DESSERTS"
        description="Falafels, Gyros, Hummes, and More!"
        src="https://i.postimg.cc/8PgKVQrn/Icons-05.png"
        color="#641C0C"
        link="/dessert"
      />
      </div>
    </div>
  );
}

function VendorCategory(props) {
  return (
    <Link to={props.link} className="nav-link2">
      <div
        id="categories"
        style={{
          backgroundColor: props.color,
        }}
      >
        <h2> {props.category}</h2>
        <p id="categoryDescription"> {props.description} </p>
        <img className="foodImage" src={props.src} alt="food" />
      </div>
    </Link>
  );
}
