import React from 'react';
import React, { useState, useEffect } from 'react';

export default function Menu() {
  return (
    <div>
      <input placeholder="Search Resturaunt" />
      <img id="search" src="https://i.postimg.cc/6qjZf5K1/fe-Search0.png" />
      <AmericanVendor
        category="Brûlée"
  
       
        url= 'url("https://i.postimg.cc/cJRGJDCs/Group-93.png")'
      />
      <AmericanVendor
        category="LA Donut"
  
       
        url= 'url("https://i.postimg.cc/ZRYN7Myn/Group-94.png")'
      />

    <AmericanVendor
        category="Cinnaholic"
  
       
        url= 'url("https://i.postimg.cc/hjCdH19r/Group-95.png")'
      />
     
    </div>
  );
}

function AmericanVendor(props) {
  return (
    <div
      id="american"
      style={{ 
        backgroundImage: props.url, backgroundRepeat: "no-repeat",      
      }}
    >
       <img id="star" src=" https://i.postimg.cc/kGQ3Z2mn/ph-star-fill.pngalt" alt ="star" />
      <h2 className= "resturaunt"> {props.category}</h2>
     
     
    </div>
  );
}
