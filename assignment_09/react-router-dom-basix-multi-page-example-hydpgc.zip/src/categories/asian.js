import React from 'react';
import React, { useState, useEffect } from 'react';

export default function Menu() {
  return (
    <div>
      <input placeholder="Search Resturaunt" />
      <img id="search" src="https://i.postimg.cc/6qjZf5K1/fe-Search0.png" />
      <AmericanVendor
        category="ChompChomp"
        url='url("https://i.postimg.cc/Px4GWKgd/Group-96.png")'
      />
      <AmericanVendor
        category="Steamy Bun Truck"
        url='url("https://i.postimg.cc/ZnKGVpmp/Group-97.png")'
      />

      <AmericanVendor
        category="Sticky Rice"
        url='url("https://i.postimg.cc/wvH8RnbW/Group-98.png")'
      />
    </div>
  );
}

function AmericanVendor(props) {
  return (
    <div
      id="american"
      style={{
        backgroundImage: props.url,
        backgroundRepeat: 'no-repeat',
      }}
    >
      <img
        id="star"
        src=" https://i.postimg.cc/kGQ3Z2mn/ph-star-fill.pngalt"
        alt="star"
      />
      <h2 className="resturaunt"> {props.category}</h2>
    </div>
  );
}
