import React from 'react';
import React, { useState, useEffect } from 'react';

export default function Menu() {
  return (
    <div>
      <input placeholder="Search Resturaunt" />
      <img id="search" src="https://i.postimg.cc/6qjZf5K1/fe-Search0.png" />
      <European
        category="The Tropic Truck  "
        url='url("https://i.postimg.cc/DZPXzjTM/Group-79.png")'
      />
      <European
        category="The Falafel Factory"
        url='url("https://i.postimg.cc/52DvKQgn/Group-81.png")'
      />

      <European
        category=" The Middle Feast"
        url='url("https://i.postimg.cc/HL5MqWPH/Group-82.png")'
      />
      <European
        category="Hummus Yummy"
        url='url("https://i.postimg.cc/ydHRsqwR/Group-83.png")'
      />
    </div>
  );
}

function European(props) {
  return (
    <div
      id="american"
      style={{
        backgroundImage: props.url,
        backgroundRepeat: 'no-repeat',
      }}
    >
      <img
        id="star"
        src=" https://i.postimg.cc/kGQ3Z2mn/ph-star-fill.pngalt"
        alt="star"
      />
      <h2 className="resturaunt"> {props.category}</h2>
    </div>
  );
}
