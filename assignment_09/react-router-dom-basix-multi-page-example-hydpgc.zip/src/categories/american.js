import React from 'react';
import React, { useState, useEffect } from 'react';

export default function Menu() {
  return (
    <div>
      <input placeholder="Search Resturaunt" />
      <img id="search" src="https://i.postimg.cc/6qjZf5K1/fe-Search0.png" />
      <AmericanVendor
        category="Fried Out"
        url='url("https://i.postimg.cc/PfFfy5L3/Group-80.png")'
      />
      <AmericanVendor
        category="Holy Cow"
        url='url("https://i.postimg.cc/SNBS01fc/Group-82.png")'
      />

      <AmericanVendor
        category="The Rooster"
        url='url("https://i.postimg.cc/kgWn7NTz/Group-81.png")'
      />

      <AmericanVendor
        category="Richeeze"
        url='url("https://i.postimg.cc/rF0VP2x8/Group-83.png")'
      />
    </div>
  );
}

function AmericanVendor(props) {
  return (
    <div
      id="american"
      style={{
        backgroundImage: props.url,
        backgroundRepeat: 'no-repeat',
      }}
    >
      <img
        id="star"
        src=" https://i.postimg.cc/kGQ3Z2mn/ph-star-fill.pngalt"
        alt="star"
      />
      <h2 className="resturaunt"> {props.category}</h2>
    </div>
  );
}
