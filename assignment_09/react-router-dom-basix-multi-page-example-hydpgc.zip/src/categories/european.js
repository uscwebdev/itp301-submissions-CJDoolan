import React from 'react';
import React, { useState, useEffect } from 'react';

export default function European() {
  return (
    <div>
      <h2>Events Page</h2>
    </div>
  );
}