import React from 'react';
import React, { useState, useEffect } from 'react';

export default function Menu() {
  return (
    <div>
      <input placeholder="Search Resturaunt" />
      <img id="search" src="https://i.postimg.cc/6qjZf5K1/fe-Search0.png" />
      <European
        category="Burrata House"
        url='url("https://i.postimg.cc/8cdrjygY/Group-79.png")'
      />
      <European
        category="Berlins"
        url='url("https://i.postimg.cc/TwDbXd7f/Group-81.png")'
      />

      <European
        category="The Jolly Oyster"
        url='url("https://i.postimg.cc/mkWHLvJM/Group-82.png")'
      />
      <European
        category="Sugo"
        url='url("https://i.postimg.cc/GhryZ1kn/Group-83.png")'
      />

  
    </div>
  );
}

function European(props) {
  return (
    <div
      id="american"
      style={{
        backgroundImage: props.url,
        backgroundRepeat: 'no-repeat',
      }}
    >
      <img
        id="star"
        src=" https://i.postimg.cc/kGQ3Z2mn/ph-star-fill.pngalt"
        alt="star"
      />
      <h2 className="resturaunt"> {props.category}</h2>
    </div>
  );
}