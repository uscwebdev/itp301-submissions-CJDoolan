import React from 'react';
import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Switch, Route, Link } from 'react-router-dom';

export default function Partners() {
  return (
    <div>
      <header>
        <img
          className="food"
          src="https://img.ctykit.com/cdn/ca-dtla/images/tr:w-1800/bankofamerica.jpg"
          alt=""
        />
      </header>
      <Item
        src="https://upload.wikimedia.org/wikipedia/commons/5/53/Seal_of_Santa_Monica%2C_California.png"
        
        src2="https://upload.wikimedia.org/wikipedia/en/thumb/3/37/Stella_Artois_logo.svg/800px-Stella_Artois_logo.svg.png"
       
      />
      <Item
        src="https://upload.wikimedia.org/wikipedia/commons/c/c1/Logo_Taj%C3%ADn.svg"
       
        src2="https://bbo-assets-www.s3.amazonaws.com/img/brands/golden.png"
        
      />
      <Item
        src="https://www.whiteclaw.com/logo-blk.png"
      
        src2="https://upload.wikimedia.org/wikipedia/commons/thumb/0/06/Food_Network_logo.svg/1200px-Food_Network_logo.svg.png"
        
      />
      <Item
        src2="https://images.squarespace-cdn.com/content/v1/59442d6b36e5d337be5da11c/0b8b8945-818b-4db4-941b-4dd43a227693/GE_logo_black_rgb.png"
      
        src="https://1000logos.net/wp-content/uploads/2020/07/San-Pellegrino-Logo.png"
        
      />
    </div>
  );
}

function Item(prop) {
  return (
    <div id="itemGroup">
      <div className="itemComponents">
        <img className="item" src={prop.src} />
        
      </div>

      <div className="itemComponents">
        <img className="item" src={prop.src2} />
        
      </div>
    </div>
  );
}
