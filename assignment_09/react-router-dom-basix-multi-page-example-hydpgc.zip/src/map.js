import React from 'react';
import React, { useState, useEffect } from 'react';

export default function Map() {
  
  return (
    <div>
      <img id= "mapImage" src= "https://i.postimg.cc/SNsQvrdY/mapp.png" alt = "map Image" />
      <input placeholder="Search Food Type" />
      <img id="search" src="https://i.postimg.cc/6qjZf5K1/fe-Search0.pngg" />
      < div className = "scroll" > < ul id = "vendorList">
        <li> Bobs Burgers </li> 
        <li> Fried out LA</li> <li> The Rooster</li> <li> Nashville Hot Chicken</li> <li> Holy Cow BBQ</li> <li> Philly Cheesesteak Sandwiches</li> <li> Job’s Daughters</li> <li> Paicitas</li> <li> G’s Tacos Spot on Wheels</li> <li> Corn Man</li> <li> The Lime Truck</li> <li> Pinch of Flavor</li> <li> White Rabbit Truck</li> <li> Kogi BBQ</li> <li> Paicitas</li> <li> ChompChomp</li> <li> Steamy Bun Truck</li> <li> Sticky Rice</li> <li> Streets of Vietnam</li> <li> Mandoline Grill</li> <li> Moon Rabbit</li> <li> Pho King Awesome</li> <li> Chow Down</li> <li> The Bollywood Kitchen</li> <li> Boba bear,</li> <li>Richeeze</li> <li> John Que’s Smokeout</li> <li> Aloha Athene</li> <li> Burrata House</li> <li> Berlins - 3rd St</li> 
        </ul>
        </div>
    </div>
  );
}
