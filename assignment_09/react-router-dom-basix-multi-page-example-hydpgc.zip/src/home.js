import React from 'react';
import React, { useState, useEffect } from 'react';

export default function Home() {

  return (
   <div> 
     <input placeholder="Search For Resturaunt" />
      <img id="search" src="https://i.postimg.cc/6qjZf5K1/fe-Search0.pngg" />
      <div class="scrollmenu">
  
        
        <img className = "poster" src="https://i.postimg.cc/bwNcdF7m/Screenshot-2023-11-07-at-8-49-10-AM.jpg" alt= "LA Food Festival" /> 
   </div>
      <p id= "homeP"> The project entails crafting and assembling a promotional package for LA Food Festival taking place in Los Angeles on April 19-21, 2024. Utilizing the 2024 festival branding and assets, the promotional package will showcase a collectible poster, a map of the site, and a 2025 calendar. These primary pieces will be accompanied by a mobile app, identification wristbands, promotional stickers, and "OTHER" which will be packaged in a box to be shipped out to the festival's top sponsors and fundraisers. Those who qualify as V.I.P.s will receive additional merchandise in their package. </p>
    </div>
  );
}
