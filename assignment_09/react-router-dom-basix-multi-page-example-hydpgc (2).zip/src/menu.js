import React from 'react';
import React, { useState, useEffect } from 'react';

export default function Menu() {
  return (
    <div>
      <input placeholder="Search Food Type" />
      <img id="search" src="https://i.postimg.cc/6qjZf5K1/fe-Search0.pngg" />
      <VendorCategory 
      category= "ALL AMERICAN"
      description= "Burgers, Pizza, Fries, and More!"
      src= "https://i.postimg.cc/fRBf7g6J/Icons-06.png"
      color = "#FAB735"
      />
 
      <VendorCategory 
      category= "LATIN AMERICAN"
      description= "Tacos, Corn, Margaritas, and More!"
      src= "https://i.postimg.cc/zXdJcjyv/Icons-09.png"
      color = "#F19846"
      />
      <VendorCategory 
      category= "ASIAN"
      description= "Pho, Noodles, Dumpling, and More!"
      src= "https://i.postimg.cc/wMLwsFnV/Icons-02.png"
      color = "#E47E49"
      />

<VendorCategory 
      category= "EUROPEAN"
      description= "Pasta, Oysters, Burratta, and More!"
      src= "https://i.postimg.cc/prbZxzyn/Icons-22.png"
      color = "#CE6240"
      />

<VendorCategory 
      category= "MEDITERRANEAN"
      description= "Falafels, Gyros, Hummes, and More!"
      src= "https://i.postimg.cc/8PgKVQrn/Icons-05.png"
      
      color = "#97391B"
      />

<VendorCategory 
      category= "DESSERTS"
      description= "Falafels, Gyros, Hummes, and More!"
      src= "https://i.postimg.cc/8PgKVQrn/Icons-05.png"
      color = "#641C0C"
      />
  
    </div>

    
  );
}

function VendorCategory(props) {
  return (
    <div id= "categories"style={{
      backgroundColor: props.color
    }} >
      <h2> {props.category}</h2>
      <p id= "categoryDescription"> {props.description} </p>
      <img className= "foodImage" src = {props.src} alt ="food"/>
    </div>
  );
}
