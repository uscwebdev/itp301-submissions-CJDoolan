import React from 'react';
import { createRoot } from 'react-dom/client';
import NewImg1 from './PhotoGallery.js';
import './index.css';

const root = createRoot(document.querySelector('#root'));

root.render(
  <React.StrictMode>
    <NewImg1 />
  </React.StrictMode>
);
