import React from 'react';
import { useState } from 'react';

export default function NewImg1() {
  const [src, setSrc] = useState(
    'https://upload.wikimedia.org/wikipedia/en/6/6a/Mike_Wazowski.png'
  );

  const [alt, setAlt] = useState('Mike Wazowski');

  const [caption, setCaption] = useState('Mike Wazowski');

  function handleImageChange(newSrc, newAlt, newCaption) {
    setSrc(newSrc);
    setAlt(newAlt);
    setCaption(newCaption);
  }

  return (
    <div id="kanye-section" className="container mt-4">
      <h2 className="col-12">Monsters Inc. Image Switch</h2>
      <img
        id="disney"
        src={src}
        alt={alt}
        // onClick={() => {
        //   handleImageChange(
        //     'https://static.tvtropes.org/pmwiki/pub/images/sulley.png',
        //     'Sully'
        //   );
        // }}
      />
      <h3 id="name"> {caption} </h3>
      <div id="buttons">
        <button
          onClick={() => {
            handleImageChange(
              'https://upload.wikimedia.org/wikipedia/en/6/6a/Mike_Wazowski.png',
              'Mike',
              'Mike Wazowski '
            );
          }}
        >
          Mike
        </button>

        <button
          onClick={() => {
            handleImageChange(
              'https://static.tvtropes.org/pmwiki/pub/images/sulley.png',
              'Sully',
              'James P. “Sulley” Sullivan '
            );
          }}
        >
          Sully
        </button>

        <button
          onClick={() => {
            handleImageChange(
              'https://preview.redd.it/his-name-is-randal-because-of-this-one-photo-i-took-all-my-v0-hvcs7deck9ca1.jpg?width=329&format=pjpg&auto=webp&s=6aead11352db56f3f01121bab41dcdd94884a382',
              'Randall',
              'Randall Boggs'
            );
          }}
        >
          Randall
        </button>

        <button
          onClick={() => {
            handleImageChange(
              'https://kh.wiki.gallery/images/1/13/Boo_KHIII.png',
              'Boo',
              'Boo'
            );
          }}
        >
          Boo
        </button>

        <button
          onClick={() => {
            handleImageChange(
              'https://m.media-amazon.com/images/I/414a7OkB57L.jpg',
              'Roz',
              'Roz'
            );
          }}
        >
          Roz
        </button>

        <button
          onClick={() => {
            handleImageChange(
              'https://i.pinimg.com/474x/cf/14/86/cf1486ad6497fa94ac03919e18c81214.jpg',
              'Celia',
              'Celia'
            );
          }}
        >
          Celia
        </button>
      </div>
    </div>
  );
}
