import React from 'react';
import { createRoot } from 'react-dom/client';
import './index.css';

const root = createRoot(document.querySelector('#root'));

root.render(
  <React.StrictMode>
    <div id="intro"> 
      <h1> Christina Doolan</h1>
    <p>
      {' '}
      To contact please email
      <a href="mailto:cdoolan@usc.edu"> cdoolan@usc.edu</a>{' '}
    </p>
    </div>
    <hr />

    <div id="sec2">
      <div id="info">
        {' '}
        <h2 className="header">Info about me:) </h2>
        <ul>
          <li>
            Favorite color: <strong id="aqua"> Aqua </strong>
          </li>
          <li>
            Favorite website: <a href="https://www.amazon.com/"> Amazon </a>{' '}
          </li>
          <li>
            Favorite Activity: Irish Dance{' '}
            <p>
              {' '}
              <img
                src="https://i.etsystatic.com/20369550/r/il/8b23fc/1901403038/il_fullxfull.1901403038_7z3l.jpg"
                alt="Dance Shoes"
              />{' '}
            </p>
          </li>
        </ul>
      </div>

      <div id="classes">
        {' '}
        <h2 className="header"> Enrolled Classes </h2>
        <ul>
          <li>PSYC 314: Experimental Research Methods</li>
          <li>LING 285: Human Language and Technology </li>
          <li>ITP 301: Front End Web Development</li>
          <li> Des 301: Design 3 </li>
          <li> PHED 119: Introduction to Mindfulness </li>
        </ul>
      </div>
    </div>
    <hr />
  </React.StrictMode>
);
