import React from 'react';

export default function Review(prop) {
  return (
    <div className="comment">
      <div className="sec1">
        <img
          src={prop.src}
          alt={prop.caption + 'Profile Pic'}
          className="profilePic"
        />

        <div className="writing">
          <p> Username: {prop.user} </p>
          <p> Date: {prop.date} </p>

          <img src={prop.src2} alt="stars" className="stars" />
        </div>
      </div>
      <br />
      <p className="review">{prop.comment}</p>
    </div>
  );
}
